<?php
/*
 |  Stock In / Stock Out (one page, two tabs).
 |  Replaces the old stockin.php, stockout.php and transaction.php.
 |  Saves through controller/stock.php, so everything is stored in the database.
 */

include('controller/authenticator.php');
requirePermission('stock.record');   // role check: staff typing this URL are sent to access_denied.php
include('database/connect.php');
require_once __DIR__ . '/controller/stock_helpers.php';

date_default_timezone_set('Asia/Manila');
$conn->set_charset('utf8mb4');
$conn->query("SET time_zone = '+08:00'");
ensureProductUnitColumn($conn);   // adds products.unit the first time

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function peso($value): string
{
    return '₱' . number_format((float) $value, 2);
}

$username = $_SESSION['user']['username'] ?? 'Admin';
$isIn     = (($_GET['type'] ?? '') !== 'out');
$type     = $isIn ? 'in' : 'out';
$table    = $isIn ? 'stock_in' : 'stock_out';
$dateCol  = $isIn ? 'received_at' : 'released_at';
$label    = $isIn ? 'Stock In' : 'Stock Out';

/* ---------- lists for the forms ---------- */

$products = [];
$res = $conn->query("SELECT id, sku, name, unit, cost_price, stock_qty FROM products ORDER BY name ASC");
while ($res && $row = $res->fetch_assoc()) {
    $products[] = [
        'id'    => (int) $row['id'],
        'sku'   => $row['sku'],
        'name'  => $row['name'],
        'cost'  => (float) $row['cost_price'],
        'stock' => (float) $row['stock_qty'],
        'unit'  => $row['unit'],              // saved unit of the product (Products page)
        'unitLabel' => unitLabel($row['unit']),
        'decimal'   => unitAllowsDecimal($row['unit']),   // only kilo may have decimals (2.5 kilo)
    ];
}

$suppliers = [];
if ($isIn) {
    $res = $conn->query("SELECT id, name, status FROM suppliers ORDER BY name ASC");
    while ($res && $row = $res->fetch_assoc()) {
        $suppliers[] = $row;
    }
}

/* ---------- this month's numbers ---------- */

$stats = $conn->query("
    SELECT COUNT(DISTINCT COALESCE(reference_no, CONCAT('#', id))) AS entries,
           COALESCE(SUM(quantity), 0) AS units,
           COALESCE(SUM(quantity * COALESCE(unit_cost, 0)), 0) AS total_value
    FROM $table
    WHERE $dateCol >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
")->fetch_assoc();

/* ---------- history (latest 500) ---------- */

if ($isIn) {
    $historySql = "
        SELECT t.id, t.reference_no, t.$dateCol AS happened, t.product_id, t.quantity, t.unit, t.unit_cost, t.remarks,
               t.supplier_id, s.name AS supplier_name, p.sku, p.name AS product_name, u.username AS by_user
        FROM stock_in t
        LEFT JOIN products  p ON p.id = t.product_id
        LEFT JOIN suppliers s ON s.id = t.supplier_id
        LEFT JOIN users     u ON u.id = t.user_id
        ORDER BY t.$dateCol DESC, t.id DESC
        LIMIT 500
    ";
} else {
    $historySql = "
        SELECT t.id, t.reference_no, t.$dateCol AS happened, t.product_id, t.quantity, t.unit, t.unit_cost, t.remarks,
               t.reason, p.sku, p.name AS product_name, u.username AS by_user
        FROM stock_out t
        LEFT JOIN products p ON p.id = t.product_id
        LEFT JOIN users    u ON u.id = t.user_id
        ORDER BY t.$dateCol DESC, t.id DESC
        LIMIT 500
    ";
}

$history = [];
$res = $conn->query($historySql);
while ($res && $row = $res->fetch_assoc()) {
    $history[] = $row;
}

// data handed to the page's JavaScript (JSON_HEX_* keeps it safe inside <script>)
$jsonFlags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($label) ?></title>

    <link rel="stylesheet" href="tailwind.min.css">

    <script src="https://kit.fontawesome.com/7fa31b9a7a.js" crossorigin="anonymous"></script>

    <style>
        body { overflow-x: hidden; }

        .form-control {
            width: 100%;
            height: 44px;
            border: 1px solid #cbd5e1;
            border-radius: 9px;
            padding: 0 13px;
            background: #ffffff;
            color: #334155;
            font-size: 14px;
            outline: none;
            transition: .2s;
        }

        .form-control:focus {
            border-color: #7c3aed;
            box-shadow: 0 0 0 3px rgba(124, 58, 237, .12);
        }

        .stock-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, .04);
        }

        .table-wrap { overflow-x: auto; }
        .line-table { min-width: 760px; }
        .history-table { min-width: 1100px; }

        .action-button {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: .2s;
        }

        .action-edit { color: #7c3aed; }
        .action-edit:hover { background: #ede9fe; }
        .action-delete { color: #ef4444; }
        .action-delete:hover { background: #fee2e2; }

        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, .55);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 100;
            padding: 20px;
        }

        .modal-overlay.active { display: flex; }

        .modal-box {
            width: 100%;
            max-width: 560px;
            max-height: 90vh;
            overflow-y: auto;
            background: white;
            border-radius: 18px;
            box-shadow: 0 25px 50px rgba(15, 23, 42, .25);
        }

        .toast {
            position: fixed;
            top: 24px;
            right: 24px;
            z-index: 200;
            color: white;
            padding: 14px 18px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .15);
            display: none;
            max-width: 90vw;
        }

        .toast.show { display: block; }
        .toast.ok { background: #16a34a; }
        .toast.bad { background: #dc2626; }
    </style>

</head>

<body class="bg-purple-200">

    <div class="grid grid-cols-1 lg:grid-cols-6 min-h-screen">

        <?php
            $activePage = "stock";
            include "partials/sidebar.php";
        ?>

        <main class="lg:col-span-5 bg-purple-200 min-h-screen">

            <!-- header -->
            <div class="bg-purple-700 p-6 shadow-lg">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5">

                    <div>
                        <p class="text-purple-200 text-sm mb-1">Inventory Management</p>
                        <h1 class="text-3xl font-bold text-white">Stock In / Out</h1>
                    </div>

                    <div class="flex items-center gap-3 bg-purple-600 rounded-xl px-5 py-3">
                        <div class="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full bg-purple-500">
                            <i class="fa-solid fa-user text-white text-lg"></i>
                        </div>
                        <div>
                            <p class="text-xs text-purple-200">Logged in as</p>
                            <p class="text-sm font-bold text-white"><?= e(strtoupper($username)) ?></p>
                        </div>
                    </div>

                </div>
            </div>

            <div class="p-6 sm:p-7 lg:p-8">

                <!-- tabs -->
                <div class="flex gap-3 mb-7">
                    <a href="stock.php?type=in"
                       class="px-6 py-3 rounded-xl font-semibold transition <?= $isIn ? 'bg-purple-700 text-white shadow-lg' : 'bg-white text-purple-700 hover:bg-purple-100' ?>">
                        <i class="fa-solid fa-arrow-trend-up mr-2"></i>Stock In
                    </a>
                    <a href="stock.php?type=out"
                       class="px-6 py-3 rounded-xl font-semibold transition <?= !$isIn ? 'bg-purple-700 text-white shadow-lg' : 'bg-white text-purple-700 hover:bg-purple-100' ?>">
                        <i class="fa-solid fa-arrow-trend-down mr-2"></i>Stock Out
                    </a>
                </div>

                <!-- this month -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-7">

                    <div class="rounded-2xl bg-blue-50 border border-blue-100 p-6">
                        <p class="text-sm font-medium text-slate-500"><?= e($label) ?> Entries (this month)</p>
                        <p class="text-4xl font-bold text-slate-900 mt-3"><?= number_format((int) $stats['entries']) ?></p>
                    </div>

                    <div class="rounded-2xl bg-green-50 border border-green-100 p-6">
                        <p class="text-sm font-medium text-slate-500">Units <?= $isIn ? 'Received' : 'Released' ?> (this month)</p>
                        <p class="text-4xl font-bold text-slate-900 mt-3"><?= e(formatQty($stats['units'])) ?></p>
                    </div>

                    <div class="rounded-2xl bg-purple-50 border border-purple-100 p-6">
                        <p class="text-sm font-medium text-slate-500">Total <?= $isIn ? 'Cost' : 'Value' ?> (this month)</p>
                        <p class="text-4xl font-bold text-slate-900 mt-3"><?= peso($stats['total_value']) ?></p>
                    </div>

                </div>

                <!-- new entry -->
                <div class="stock-card p-6 sm:p-7 mb-7">

                    <h2 class="text-xl font-bold text-slate-900 mb-1">New <?= e($label) ?></h2>
                    <p class="text-sm text-slate-500 mb-6">
                        Add one or more products. They are saved together under one reference number.
                    </p>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">

                        <div>
                            <label class="block text-sm font-semibold text-slate-700 mb-2" for="entryDate">
                                Date <span class="text-red-500">*</span>
                            </label>
                            <input type="date" id="entryDate" class="form-control"
                                   value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>">
                        </div>

                        <?php if ($isIn): ?>
                            <div>
                                <label class="block text-sm font-semibold text-slate-700 mb-2" for="entrySupplier">
                                    Supplier <span class="text-slate-400 font-normal">(optional)</span>
                                </label>
                                <select id="entrySupplier" class="form-control">
                                    <option value="">No supplier</option>
                                    <?php foreach ($suppliers as $s): ?>
                                        <option value="<?= (int) $s['id'] ?>">
                                            <?= e($s['name']) ?><?= $s['status'] === 'pending' ? ' (pending)' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="text-xs text-slate-400 mt-1">
                                    <?= $suppliers ? 'Optional. You can save without a supplier.' : 'Optional. No suppliers yet (add them in the Suppliers page).' ?>
                                </p>
                            </div>
                        <?php else: ?>
                            <div>
                                <label class="block text-sm font-semibold text-slate-700 mb-2" for="entryReason">
                                    Reason <span class="text-red-500">*</span>
                                </label>
                                <select id="entryReason" class="form-control">
                                    <option value="">Select reason</option>
                                    <?php foreach (stockOutReasons() as $r): ?>
                                        <option value="<?= e($r) ?>"><?= e($r) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div>
                            <label class="block text-sm font-semibold text-slate-700 mb-2" for="entryRemarks">Remarks</label>
                            <input type="text" id="entryRemarks" class="form-control" maxlength="255" placeholder="Optional">
                        </div>

                    </div>

                    <div class="table-wrap border border-slate-200 rounded-xl">
                        <table class="line-table w-full text-sm">
                            <thead class="bg-slate-50 text-left text-slate-500">
                                <tr>
                                    <th class="px-4 py-3">Product</th>
                                    <th class="px-4 py-3 w-28">Quantity</th>
                                    <th class="px-4 py-3 w-32">Unit</th>
                                    <?php if ($isIn): ?>
                                        <th class="px-4 py-3 w-36">Unit Cost</th>
                                    <?php endif; ?>
                                    <th class="px-4 py-3 w-36 text-right">Total</th>
                                    <th class="px-4 py-3 w-14"></th>
                                </tr>
                            </thead>
                            <tbody id="lineBody" class="divide-y divide-slate-100"></tbody>
                        </table>
                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-5">

                        <button type="button" id="addLineButton"
                                class="px-5 py-3 rounded-xl border border-purple-300 text-purple-700 font-semibold hover:bg-purple-50 transition">
                            <i class="fa-solid fa-plus mr-2"></i>Add product
                        </button>

                        <div class="text-right">
                            <p class="text-sm text-slate-500">
                                <span id="lineCount">0</span> product(s) &middot; Total <?= $isIn ? 'cost' : 'value' ?>
                            </p>
                            <p id="grandTotal" class="text-2xl font-bold text-purple-700">₱0.00</p>
                        </div>

                    </div>

                    <div class="flex justify-end gap-3 mt-6">
                        <button type="button" id="clearButton"
                                class="px-6 py-3 rounded-xl bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200 transition">
                            Clear
                        </button>
                        <button type="button" id="saveButton"
                                class="px-6 py-3 rounded-xl bg-purple-700 text-white font-semibold hover:bg-purple-800 transition">
                            <i class="fa-solid fa-floppy-disk mr-2"></i>Save <?= e($label) ?>
                        </button>
                    </div>

                </div>

                <!-- history -->
                <div class="stock-card p-6 sm:p-7">

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-5">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900"><?= e($label) ?> History</h2>
                            <p id="showingText" class="text-sm text-slate-500"></p>
                        </div>
                        <input type="text" id="searchInput" class="form-control sm:max-w-xs"
                               placeholder="Search reference, product, <?= $isIn ? 'supplier' : 'reason' ?>...">
                    </div>

                    <div class="table-wrap">
                        <table class="history-table w-full text-sm">
                            <thead class="text-left text-slate-500 border-b border-slate-200">
                                <tr>
                                    <th class="px-4 py-3">Reference</th>
                                    <th class="px-4 py-3">Date</th>
                                    <th class="px-4 py-3">Product</th>
                                    <th class="px-4 py-3">Quantity</th>
                                    <th class="px-4 py-3"><?= $isIn ? 'Supplier' : 'Reason' ?></th>
                                    <th class="px-4 py-3 text-right">Unit Cost</th>
                                    <th class="px-4 py-3 text-right">Total</th>
                                    <th class="px-4 py-3">Recorded By</th>
                                    <th class="px-4 py-3">Remarks</th>
                                    <th class="px-4 py-3 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="historyBody" class="divide-y divide-slate-100">

                                <?php foreach ($history as $r): ?>
                                    <?php
                                        $cost  = (float) ($r['unit_cost'] ?? 0);
                                        $other = $isIn ? ($r['supplier_name'] ?? 'No supplier') : ($r['reason'] ?? '—');
                                    ?>
                                    <tr class="history-row hover:bg-slate-50">
                                        <td class="px-4 py-4 font-semibold text-purple-700"><?= e($r['reference_no'] ?: '—') ?></td>
                                        <td class="px-4 py-4 whitespace-nowrap"><?= e(date('M d, Y', strtotime($r['happened']))) ?></td>
                                        <td class="px-4 py-4">
                                            <?php if ($r['product_name']): ?>
                                                <p class="font-semibold text-slate-800"><?= e($r['product_name']) ?></p>
                                                <p class="text-xs text-slate-400"><?= e($r['sku']) ?></p>
                                            <?php else: ?>
                                                <p class="text-slate-400 italic">(deleted product)</p>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-4 whitespace-nowrap"><?= e(formatQty($r['quantity'])) ?> <?= e(unitLabel($r['unit'])) ?></td>
                                        <td class="px-4 py-4"><?= e($other ?: '—') ?></td>
                                        <td class="px-4 py-4 text-right"><?= peso($cost) ?></td>
                                        <td class="px-4 py-4 text-right font-semibold"><?= peso($cost * (float) $r['quantity']) ?></td>
                                        <td class="px-4 py-4"><?= e($r['by_user'] ?: '—') ?></td>
                                        <td class="px-4 py-4 max-w-xs truncate" title="<?= e($r['remarks']) ?>"><?= e($r['remarks'] ?: '—') ?></td>
                                        <td class="px-4 py-4 text-center whitespace-nowrap">
                                            <?php if (!can('stock.edit')): ?>
                                                <span class="text-slate-300">—</span>
                                            <?php else: ?>
                                            <?php if ($r['product_id']): ?>
                                                <button type="button" class="action-button action-edit edit-button" title="Edit"
                                                        data-id="<?= (int) $r['id'] ?>"
                                                        data-product="<?= (int) $r['product_id'] ?>"
                                                        data-quantity="<?= e(formatQty($r['quantity'], false)) ?>"
                                                        data-unit="<?= e($r['unit']) ?>"
                                                        data-date="<?= e(substr($r['happened'], 0, 10)) ?>"
                                                        data-supplier="<?= $isIn && $r['supplier_id'] ? (int) $r['supplier_id'] : '' ?>"
                                                        data-reason="<?= $isIn ? '' : e($r['reason']) ?>"
                                                        data-cost="<?= e($cost) ?>"
                                                        data-remarks="<?= e($r['remarks']) ?>">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </button>
                                            <?php endif; ?>
                                            <button type="button" class="action-button action-delete delete-button" title="Delete"
                                                    data-id="<?= (int) $r['id'] ?>">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                            </tbody>
                        </table>
                    </div>

                    <div id="emptyMessage" class="py-14 text-center text-slate-400" style="display:none">
                        <i class="fa-solid fa-box-open text-4xl mb-3"></i>
                        <p class="font-semibold">No <?= e($label) ?> records found</p>
                    </div>

                </div>

            </div>

        </main>

    </div>

    <!-- edit one record -->
    <div id="editModal" class="modal-overlay">
        <div class="modal-box">

            <div class="flex items-center justify-between p-6 border-b border-slate-200">
                <h3 class="text-lg font-bold text-slate-900">Edit <?= e($label) ?> Record</h3>
                <button type="button" id="editClose" class="text-slate-400 hover:text-slate-700 text-xl">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div class="p-6 grid grid-cols-1 sm:grid-cols-2 gap-5">

                <div class="sm:col-span-2">
                    <label class="block text-sm font-semibold text-slate-700 mb-2" for="editProduct">Product</label>
                    <select id="editProduct" class="form-control"></select>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2" for="editQuantity">Quantity</label>
                    <input type="number" id="editQuantity" class="form-control" min="0.001" step="1">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2" for="editUnit">Unit</label>
                    <input type="text" id="editUnit" class="form-control bg-slate-100" readonly
                           title="The unit comes from the product (Products page)">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2" for="editDate">Date</label>
                    <input type="date" id="editDate" class="form-control" max="<?= date('Y-m-d') ?>">
                </div>

                <?php if ($isIn): ?>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2" for="editSupplier">Supplier <span class="text-slate-400 font-normal">(optional)</span></label>
                        <select id="editSupplier" class="form-control">
                            <option value="">No supplier</option>
                            <?php foreach ($suppliers as $s): ?>
                                <option value="<?= (int) $s['id'] ?>"><?= e($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2" for="editCost">Unit Cost</label>
                        <input type="number" id="editCost" class="form-control" min="0" step="0.01">
                    </div>
                <?php else: ?>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2" for="editReason">Reason</label>
                        <select id="editReason" class="form-control">
                            <?php foreach (stockOutReasons() as $r): ?>
                                <option value="<?= e($r) ?>"><?= e($r) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="sm:col-span-2">
                    <label class="block text-sm font-semibold text-slate-700 mb-2" for="editRemarks">Remarks</label>
                    <input type="text" id="editRemarks" class="form-control" maxlength="255">
                </div>

            </div>

            <div class="flex justify-end gap-3 p-6 border-t border-slate-200">
                <button type="button" id="editCancel"
                        class="px-6 py-3 rounded-xl bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200 transition">
                    Cancel
                </button>
                <button type="button" id="editSave"
                        class="px-6 py-3 rounded-xl bg-purple-700 text-white font-semibold hover:bg-purple-800 transition">
                    Save changes
                </button>
            </div>

        </div>
    </div>

    <div id="toast" class="toast"></div>

    <script>
        const TYPE      = <?= json_encode($type) ?>;
        const IS_IN     = TYPE === "in";
        const CSRF      = <?= json_encode(csrfToken()) ?>;
        const PRODUCTS  = <?= json_encode($products, $jsonFlags) ?>;

        const $ = (id) => document.getElementById(id);

        const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => (
            { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
        ));

        const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", {
            minimumFractionDigits: 2, maximumFractionDigits: 2
        });

        const findProduct = (id) => PRODUCTS.find((p) => String(p.id) === String(id));

        // quantities: whole numbers, except products counted in KILO (up to 3 decimals, e.g. 2.5 or 0.250)
        const isDecimalProduct = (id) => !!(findProduct(id) || {}).decimal;
        const qtyStep = (id) => isDecimalProduct(id) ? "0.001" : "1";

        const fmtQty = (n) => {
            const v = Math.round(Number(n || 0) * 1000) / 1000;
            return v.toLocaleString("en-US", { maximumFractionDigits: 3 });
        };

        // returns an error text, or "" when the quantity is fine for this product
        function qtyError(id, value) {
            const q = Number(value);
            const p = findProduct(id);
            const unit = p ? p.unitLabel : "";

            if (String(value).trim() === "" || !isFinite(q) || q <= 0) {
                return isDecimalProduct(id)
                    ? "Quantity must be greater than zero."
                    : "Quantity must be a whole number greater than zero.";
            }
            if (isDecimalProduct(id)) {
                if (Math.abs(Math.round(q * 1000) / 1000 - q) > 1e-9) {
                    return "Kilo quantities can have at most 3 decimals (for example 2.5 or 0.250).";
                }
            } else if (!Number.isInteger(q)) {
                return 'This product is counted in ' + unit + ', so the quantity must be a whole number. Only products in kilo can have decimals.';
            }
            return "";
        }

        /* ---------- messages ---------- */

        let toastTimer;

        function toast(message, ok = true) {
            const box = $("toast");
            box.textContent = message;
            box.className = "toast show " + (ok ? "ok" : "bad");
            clearTimeout(toastTimer);
            toastTimer = setTimeout(() => box.classList.remove("show"), 4500);
        }

        // message saved before a page reload
        try {
            const flash = sessionStorage.getItem("stockFlash");
            if (flash) {
                sessionStorage.removeItem("stockFlash");
                toast(flash);
            }
        } catch (err) { /* storage not available: ignore */ }

        function reloadWith(message) {
            try { sessionStorage.setItem("stockFlash", message); } catch (err) { }
            window.location.href = "stock.php?type=" + TYPE;
        }

        async function api(payload) {
            let data = {};
            let res;

            try {
                res = await fetch("controller/stock.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json", "X-CSRF-Token": CSRF },
                    body: JSON.stringify({ type: TYPE, ...payload })
                });
                data = await res.json();
            } catch (err) {
                throw new Error("Could not reach the server. Please try again.");
            }

            if (!res.ok || data.error) {
                throw new Error(data.error || "Something went wrong. Please try again.");
            }

            return data;
        }

        /* ---------- helpers for selects ---------- */

        function productOptions(selectedId) {
            return '<option value="">Select product</option>' + PRODUCTS.map((p) =>
                `<option value="${p.id}" ${String(p.id) === String(selectedId) ? "selected" : ""}>${esc(p.name)} (${esc(p.sku)})</option>`
            ).join("");
        }

        // the unit is not typed or chosen here: it is the unit of the product (Products page)
        function unitText(productId) {
            const p = findProduct(productId);
            return p ? p.unitLabel : "—";
        }

        /* ---------- new entry: product lines ---------- */

        const lineBody = $("lineBody");

        function addLine() {
            const tr = document.createElement("tr");
            tr.className = "line-row";

            tr.innerHTML = `
                <td class="px-4 py-3">
                    <select class="form-control line-product">${productOptions("")}</select>
                    <p class="line-hint text-xs text-slate-400 mt-1"></p>
                </td>
                <td class="px-4 py-3"><input type="number" class="form-control line-qty" min="0" step="1" placeholder="0"></td>
                <td class="px-4 py-3 text-slate-600 font-medium line-unit">—</td>
                ${IS_IN ? '<td class="px-4 py-3"><input type="number" class="form-control line-cost" min="0" step="0.01" placeholder="0.00"></td>' : ""}
                <td class="px-4 py-3 text-right font-semibold line-total">₱0.00</td>
                <td class="px-4 py-3 text-center">
                    <button type="button" class="action-button action-delete line-remove" title="Remove">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </td>
            `;

            lineBody.appendChild(tr);
            recalc();
        }

        function lineCost(tr) {
            if (IS_IN) {
                return Number(tr.querySelector(".line-cost").value) || 0;
            }
            const p = findProduct(tr.querySelector(".line-product").value);
            return p ? p.cost : 0;
        }

        function recalc() {
            let total = 0;
            const rows = lineBody.querySelectorAll(".line-row");

            rows.forEach((tr) => {
                const qty  = Number(tr.querySelector(".line-qty").value) || 0;
                const line = qty * lineCost(tr);
                tr.querySelector(".line-total").textContent = peso(line);
                total += line;
            });

            $("lineCount").textContent = rows.length;
            $("grandTotal").textContent = peso(total);
        }

        lineBody.addEventListener("change", (event) => {
            if (!event.target.classList.contains("line-product")) return;

            const tr = event.target.closest("tr");
            const p  = findProduct(event.target.value);

            if (p) {
                if (IS_IN) {
                    tr.querySelector(".line-cost").value = p.cost.toFixed(2);
                }
            }

            tr.querySelector(".line-unit").textContent = unitText(event.target.value);
            tr.querySelector(".line-hint").textContent = p ? "In stock: " + fmtQty(p.stock) + " " + p.unitLabel : "";

            // kilo products accept decimals, every other unit only whole numbers
            const qtyInput = tr.querySelector(".line-qty");
            qtyInput.step = qtyStep(event.target.value);
            qtyInput.min = isDecimalProduct(event.target.value) ? "0.001" : "1";
            qtyInput.placeholder = isDecimalProduct(event.target.value) ? "0.000" : "0";
            recalc();
        });

        lineBody.addEventListener("input", recalc);

        lineBody.addEventListener("click", (event) => {
            const button = event.target.closest(".line-remove");
            if (!button) return;

            button.closest("tr").remove();

            if (!lineBody.querySelector(".line-row")) addLine();
            recalc();
        });

        $("addLineButton").addEventListener("click", addLine);

        $("clearButton").addEventListener("click", () => {
            lineBody.innerHTML = "";
            $("entryRemarks").value = "";
            addLine();
        });

        $("saveButton").addEventListener("click", async () => {
            const date = $("entryDate").value;
            const supplierId = IS_IN ? $("entrySupplier").value : "";
            const reason = IS_IN ? "" : $("entryReason").value;

            if (!date) return toast("Please choose a date.", false);
            if (!IS_IN && !reason) return toast("Please select a reason.", false);

            const items = [];
            const used = {};

            for (const tr of lineBody.querySelectorAll(".line-row")) {
                const productId = tr.querySelector(".line-product").value;
                const quantity  = Number(tr.querySelector(".line-qty").value);

                if (!productId) return toast("Please choose a product on every line.", false);

                const problem = qtyError(productId, tr.querySelector(".line-qty").value);
                if (problem) return toast(problem, false);

                const item = {
                    product_id: Number(productId),
                    quantity: quantity,
                    unit: (findProduct(productId) || {}).unit || ""   // the server uses the product's own unit anyway
                };

                if (IS_IN) {
                    const cost = tr.querySelector(".line-cost").value;
                    if (cost === "" || Number(cost) < 0) return toast("Please enter a unit cost on every line.", false);
                    item.unit_cost = Number(cost);
                } else {
                    used[productId] = Math.round(((used[productId] || 0) + quantity) * 1000) / 1000;
                    const p = findProduct(productId);

                    if (p && used[productId] > p.stock) {
                        return toast('Not enough stock of "' + p.name + '" (only ' + fmtQty(p.stock) + " available).", false);
                    }
                }

                items.push(item);
            }

            const button = $("saveButton");
            button.disabled = true;

            try {
                const data = await api({
                    action: "batch",
                    date: date,
                    supplier_id: supplierId,
                    reason: reason,
                    remarks: $("entryRemarks").value.trim(),
                    items: items
                });

                reloadWith(data.message);
            } catch (err) {
                toast(err.message, false);
                button.disabled = false;
            }
        });

        /* ---------- history: search ---------- */

        const rows = Array.from(document.querySelectorAll(".history-row"));

        function filterHistory() {
            const term = $("searchInput").value.trim().toLowerCase();
            let shown = 0;

            rows.forEach((tr) => {
                const match = tr.textContent.toLowerCase().includes(term);
                tr.style.display = match ? "" : "none";
                if (match) shown++;
            });

            $("emptyMessage").style.display = shown === 0 ? "block" : "none";
            $("showingText").textContent = "Showing " + shown + " of " + rows.length + " record(s)";
        }

        $("searchInput").addEventListener("input", filterHistory);

        /* ---------- history: edit and delete ---------- */

        let editingId = 0;

        function openEdit(button) {
            const d = button.dataset;
            editingId = Number(d.id);

            $("editProduct").innerHTML = productOptions(d.product);
            $("editQuantity").value = d.quantity;
            $("editQuantity").step = qtyStep(d.product);
            $("editUnit").value = unitText(d.product);
            $("editDate").value = d.date;
            $("editRemarks").value = d.remarks;

            if (IS_IN) {
                $("editSupplier").value = d.supplier;
                $("editCost").value = d.cost;
            } else {
                $("editReason").value = d.reason;
            }

            $("editModal").classList.add("active");
        }

        function closeEdit() {
            $("editModal").classList.remove("active");
        }

        $("editProduct").addEventListener("change", () => {
            $("editUnit").value = unitText($("editProduct").value);
            $("editQuantity").step = qtyStep($("editProduct").value);
        });

        $("editClose").addEventListener("click", closeEdit);
        $("editCancel").addEventListener("click", closeEdit);

        $("editModal").addEventListener("click", (event) => {
            if (event.target === $("editModal")) closeEdit();
        });

        $("editSave").addEventListener("click", async () => {
            const button = $("editSave");

            const editProblem = qtyError($("editProduct").value, $("editQuantity").value);
            if (!$("editProduct").value) return toast("Please choose a product.", false);
            if (editProblem) return toast(editProblem, false);

            button.disabled = true;

            const payload = {
                action: "update",
                id: editingId,
                product_id: Number($("editProduct").value),
                quantity: Number($("editQuantity").value),
                unit: (findProduct($("editProduct").value) || {}).unit || "",
                date: $("editDate").value,
                remarks: $("editRemarks").value.trim()
            };

            if (IS_IN) {
                payload.supplier_id = $("editSupplier").value;
                payload.unit_cost = $("editCost").value;
            } else {
                payload.reason = $("editReason").value;
            }

            try {
                const data = await api(payload);
                reloadWith(data.message);
            } catch (err) {
                toast(err.message, false);
                button.disabled = false;
            }
        });

        $("historyBody").addEventListener("click", async (event) => {
            const edit = event.target.closest(".edit-button");
            const del  = event.target.closest(".delete-button");

            if (edit) {
                openEdit(edit);
                return;
            }

            if (del) {
                if (!confirm("Delete this record? The product stock will be adjusted back.")) return;

                try {
                    const data = await api({ action: "delete", id: Number(del.dataset.id) });
                    reloadWith(data.message);
                } catch (err) {
                    toast(err.message, false);
                }
            }
        });

        /* ---------- start ---------- */

        addLine();
        filterHistory();
    </script>

</body>

</html>
