<?php

    session_start();

    // "Sign Up" is only offered while the system has no users at all (first setup).
    // After that, only an Admin creates accounts (Users page).
    require_once __DIR__ . '/database/connect.php';
    $noUsers = ((int) $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0]) === 0;

    $success = $_SESSION['success'] ?? '';
    unset($_SESSION['success']);

    $error = $_SESSION['error'] ?? '';
    unset($_SESSION['error']);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>

    <link rel="stylesheet" href="tailwind.min.css">

    <script
        src="https://kit.fontawesome.com/7fa31b9a7a.js"
        crossorigin="anonymous">
    </script>

</head>

<body class="min-h-screen flex items-center justify-center bg-purple-700">

    <div class="bg-purple-600 shadow-lg w-full rounded-xl max-w-md px-10 py-10">

        <div class="text-center mb-8">

            <h1 class="text-5xl font-bold text-white">
                Login
            </h1>

        </div>

        <form method="POST" action="controller/login.php">

            <!-- Username -->
            <div>

                <label class="block text-white font-semibold mb-2">
                    Username
                </label>

                <div class="relative">

                    <i
                        class="fa-solid fa-id-badge absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none">
                    </i>

                    <input
                        type="text"
                        name="username"
                        placeholder="Enter your username"
                        required
                        class="w-full rounded-xl bg-white py-3 pl-11 pr-4 outline-none focus:ring-2 focus:ring-blue-500"
                    >

                </div>

            </div>


            <!-- Password -->
            <div class="mt-4">

                <label class="block text-white font-semibold mb-2">
                    Password
                </label>

                <div class="relative">

                    <i
                        class="fa-solid fa-lock absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none">
                    </i>

                    <input
                        type="password"
                        name="password"
                        placeholder="Enter password"
                        required
                        class="w-full rounded-xl bg-white py-3 pl-11 pr-4 outline-none focus:ring-2 focus:ring-blue-500"
                    >

                </div>

            </div>


            <!-- Login Button -->
            <button
                type="submit"
                class="w-full mt-6 bg-indigo-600 hover:bg-indigo-700 transition duration-300 text-white text-xl font-semibold py-3 rounded-xl shadow-lg"
            >
                Login
            </button>


            <!-- Success Message -->
            <?php if ($success): ?>

                <div class="w-full mt-4 bg-green-300 text-green-700 text-md text-center py-2 rounded">

                    <?= htmlspecialchars($success, ENT_QUOTES, "UTF-8"); ?>

                </div>

            <?php endif; ?>


            <!-- Error Message -->
            <?php if ($error): ?>

                <div class="w-full mt-4 bg-red-300 text-red-700 text-md text-center py-2 rounded">

                    <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8"); ?>

                </div>

            <?php endif; ?>


            <!-- First-time setup only -->
            <?php if ($noUsers): ?>
            <p class="text-center text-white mt-8">

                No accounts yet?

                <a
                    href="registration.php"
                    class="font-bold hover:underline"
                >
                    Create the first (Admin) account
                </a>

            </p>
            <?php endif; ?>

        </form>

    </div>

</body>

</html>